Quickproject creates the skeleton of a Common Lisp project.

For full documentation, see doc/index.html.

Quickproject is licensed under the MIT license; see LICENSE.txt for
details.

For questions or comments, please email Zach Beane <xach@xach.com>.
